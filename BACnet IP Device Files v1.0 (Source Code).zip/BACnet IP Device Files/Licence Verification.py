# The purpose of this module is to determine the validity of the license key entered/ if existing.
# Also prevents the install of software across multiple systems without obtaining a new key.
# This software package was developed by Brendan White whilst interning at Johnson Controls Australia (North Ryde)
# Source code may only be altered by an authorised employee of Johnson Controls
# External entities must not attempt to obtain or reproduce this source code.
# version 1.0, date modified: 12.08.2024

import uuid 
import sys
# fetch the current systems MAC address
def getMacAddress():
    mac = uuid.getnode()
    return mac
# reads the current license key and determines if it is the expected value
def readLicenseFile(file_path):
    with open(file_path, 'r') as file:
        value = int(file.read().strip())
        return value

# logic to verify the license key validity. Prevents multiple device use on one license
def verifyKey(file_path, multiplier):
    stored_value = readLicenseFile(file_path)
    current_mac = getMacAddress()
    expected_value = current_mac * multiplier
    
    if stored_value == expected_value:
        print("Verification successful. The key matches.")
        return True
    else:
        print("Verification failed. The key does not match.")
        return False
    
# runs the script to check expected value against the entered key
file_path = './nssm-2.24/license_key.txt'
key_multiplier = 263

if not verifyKey(file_path, key_multiplier):
    sys.exit("Exiting script due to failed verification.")