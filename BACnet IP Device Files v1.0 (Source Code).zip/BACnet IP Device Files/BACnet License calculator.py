# helper script that calculates the license key based upon the users system MAC address
# not to be distributed with the Virtual BACnet device software package
# developed by Brendan White
# Version 1.0, date modified: 12.08.2024

import tkinter as tk

# Define the function to multiply the input by 263
def generateLicense():
    try:
        # Get the input value
        input_value = int(entry.get())
        # Multiply by 263
        result = input_value * 263
        # Set the result in the entry widget
        result_entry.delete(0, tk.END)
        result_entry.insert(0, str(result))
    except ValueError:
        # Show an error message if input is not a valid number
        result_entry.delete(0, tk.END)
        result_entry.insert(0, "Invalid input")

# Create the main window
root = tk.Tk()
root.title("Number Multiplier")

# Create an entry widget for user input
entry = tk.Entry(root)
entry.pack(pady=10)

# Create a button to trigger the multiplication
button = tk.Button(root, text="Generate License", command=generateLicense)
button.pack()

# Create an entry widget to display the result
result_entry = tk.Entry(root)
result_entry.pack(pady=10)

root.geometry("200x150")
root.resizable(False, False)

# Start the GUI event loop
root.mainloop()